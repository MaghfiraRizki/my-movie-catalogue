package com.maghfira_m.mymoviecatalogue.core.utils

object Config {
    const val BASE_URL = "https://api.themoviedb.org/3/"
    const val IMAGE_URL = "https://image.tmdb.org/t/p/w500"
    const val API_KEY = "80986811b097c51cbfa0df0e5fe0419b"
}